#!/usr/bin/env python
#-*- coding:utf-8 -*-
with open('江西.text','w',encoding=('utf8')) as f :
    a=f.write('1')
